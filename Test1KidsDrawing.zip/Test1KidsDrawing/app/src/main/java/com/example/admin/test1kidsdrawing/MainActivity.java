package com.example.admin.test1kidsdrawing;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.admin.test1kidsdrawing.model.DrawDb;

public class MainActivity extends AppCompatActivity {
    GridView gridView;
    private int[] imageFlags = new int[210];

    private ImageButton leftBarBtn, topBarBtn, rightBarBtn, bottomBarBtn, topLeftBarBtn, topRightBarBtn, bottomLeftBarBtn, bottomRightBarBtn;
    private Button saveBtn, loadBtn, clearBtn, clearBoxBtn;
    private ImageView selectedImageView;
    private int selectedPos;

    private AlertDialog.Builder alertBuilder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = (GridView) findViewById(R.id.gridView);
        gridView.setAdapter(new ImageAdapter(this));

        leftBarBtn = (ImageButton) findViewById(R.id.leftBarBtn);
        topBarBtn = (ImageButton) findViewById(R.id.topBarBtn);
        rightBarBtn = (ImageButton) findViewById(R.id.rightBarBtn);
        bottomBarBtn = (ImageButton) findViewById(R.id.bottomBarBtn);
        topLeftBarBtn = (ImageButton) findViewById(R.id.topLeftBarBtn);
        topRightBarBtn = (ImageButton) findViewById(R.id.topRightBarBtn);
        bottomLeftBarBtn = (ImageButton) findViewById(R.id.bottomLeftBarBtn);
        bottomRightBarBtn = (ImageButton) findViewById(R.id.bottomRightBarBtn);

        saveBtn = (Button) findViewById(R.id.saveBtn);
        loadBtn = (Button) findViewById(R.id.loadBtn);
        clearBtn = (Button) findViewById(R.id.clearBtn);
        clearBoxBtn = (Button) findViewById(R.id.clearBoxBtn);

        for (int i = 0; i < imageFlags.length; i++) {
            imageFlags[i] = 0;
        }
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedImageView = (ImageView) view;
                selectedPos = position;
            }
        });

        leftBarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedImageView != null) {
                    selectedImageView.setImageResource(R.drawable.left_bar);
                    imageFlags[selectedPos] = 1;
                }
            }
        });

        topBarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedImageView != null) {
                    selectedImageView.setImageResource(R.drawable.top_bar);
                    imageFlags[selectedPos] = 2;
                }
            }
        });

        rightBarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedImageView != null) {
                    selectedImageView.setImageResource(R.drawable.right_bar);
                    imageFlags[selectedPos] = 3;
                }
            }
        });

        bottomBarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedImageView != null) {
                    selectedImageView.setImageResource(R.drawable.bottom_bar);
                    imageFlags[selectedPos] = 4;
                }
            }
        });

        topLeftBarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedImageView != null) {
                    selectedImageView.setImageResource(R.drawable.top_left_bar);
                    imageFlags[selectedPos] = 5;
                }
            }
        });

        topRightBarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedImageView != null) {
                    selectedImageView.setImageResource(R.drawable.top_right_bar);
                    imageFlags[selectedPos] = 6;
                }
            }
        });

        bottomLeftBarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedImageView != null) {
                    selectedImageView.setImageResource(R.drawable.bottom_left_bar);
                    imageFlags[selectedPos] = 7;
                }
            }
        });

        bottomRightBarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedImageView != null) {
                    selectedImageView.setImageResource(R.drawable.bottom_right_bar);
                    imageFlags[selectedPos] = 8;
                }
            }
        });

        clearBoxBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedImageView != null) {
                    selectedImageView.setImageResource(R.drawable.light_thumb);
                    imageFlags[selectedPos] = 0;
                }
            }
        });

        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertBuilder = new AlertDialog.Builder(MainActivity.this);

                alertBuilder.setCancelable(false);
                alertBuilder.setTitle("Clear draw?");
                alertBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        clearFunc();
                    }
                });
                alertBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                AlertDialog alertDialog = alertBuilder.create();
                alertDialog.show();
            }
        });

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertBuilder = new AlertDialog.Builder(MainActivity.this);

                alertBuilder.setCancelable(false);
                alertBuilder.setTitle("Save draw?");
                alertBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        saveFunc();
                    }
                });
                alertBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                AlertDialog alertDialog = alertBuilder.create();
                alertDialog.show();
            }
        });

        loadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertBuilder = new AlertDialog.Builder(MainActivity.this);

                alertBuilder.setCancelable(false);
                alertBuilder.setTitle("Load last saved draw?");
                alertBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        loadFunc();
                    }
                });
                alertBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                AlertDialog alertDialog = alertBuilder.create();
                alertDialog.show();
            }
        });
    }

    private void loadFunc() {
        DrawDb db = new DrawDb(MainActivity.this);
        imageFlags = db.load();
        for(int i=0; i < gridView.getChildCount(); i++) {
            ImageView child = (ImageView) gridView.getChildAt(i);
            int resId;
            if (imageFlags[i] == 0) {
                resId = R.drawable.light_thumb;
            } else if (imageFlags[i] == 1) {
                resId = R.drawable.left_bar;
            } else if (imageFlags[i] == 2) {
                resId = R.drawable.top_bar;
            } else if (imageFlags[i] == 3) {
                resId = R.drawable.right_bar;
            } else if (imageFlags[i] == 4) {
                resId = R.drawable.bottom_bar;
            } else if (imageFlags[i] == 5) {
                resId = R.drawable.top_left_bar;
            } else if (imageFlags[i] == 6) {
                resId = R.drawable.top_right_bar;
            } else if (imageFlags[i] == 7) {
                resId = R.drawable.bottom_left_bar;
            } else {
                resId = R.drawable.bottom_right_bar;
            }

            child.setImageResource(resId);
        }
    }

    private void saveFunc() {
        DrawDb db = new DrawDb(MainActivity.this);
        for (int i = 0; i < imageFlags.length; i++) {
            Log.d("asd", String.valueOf(imageFlags[i]));
        }
        db.save(imageFlags);
        db.close();
        Toast.makeText(MainActivity.this, "Save successful!", Toast.LENGTH_SHORT).show();
    }

    private void clearFunc(){
        for(int i=0; i < gridView.getChildCount(); i++) {
            ImageView child = (ImageView) gridView.getChildAt(i);
            child.setImageResource(R.drawable.light_thumb);
            selectedImageView = null;
            selectedPos = -1;
            imageFlags[i] = 0;
        }
    }


}
