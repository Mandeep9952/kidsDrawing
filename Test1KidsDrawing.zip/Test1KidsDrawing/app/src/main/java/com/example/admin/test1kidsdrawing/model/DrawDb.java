package com.example.admin.test1kidsdrawing.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by admin on 8/7/2017.
 */

public class DrawDb extends SQLiteOpenHelper {

    public DrawDb(Context context) {
        super(context, "DrawingDB", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE DrawingTable (imageCode INTEGER)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql = "DROP TABLE IF EXISTS DrawingTable";
        db.execSQL(sql);
        onCreate(db);
    }

    public void save(int[] imageCodes) {
        String sql = "DELETE FROM DrawingTable";
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL(sql);

        for (int i = 0; i < imageCodes.length; i++) {
            //sql = "INSERT INTO DrawingTable VALUES(" + imageCodes[i] + ")";
            ContentValues insertValues = new ContentValues();
            insertValues.put("imageCode", imageCodes[i]);
            db.insert("DrawingTable", null, insertValues);
            //db.execSQL(sql);
            Log.d("imageCode", String.valueOf(imageCodes[i]));
        }


    }

    public int[] load() {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM DrawingTable";

        Cursor c = db.rawQuery(sql, null);

        int[] imageCodes = new int[210];
        int i = 0;
        while (c.moveToNext()) {
            imageCodes[i] = c.getInt(c.getColumnIndex("imageCode"));
            i++;
        }

        c.close();
        return  imageCodes;
    }
}
